// Apps Script: kloca-lens-vision
// 사진(base64) -> Gemini vision -> 음식 이름(한국어) 반환
// GEMINI_KEY는 스크립트 속성으로 등록 (코드에 키를 넣지 않는다)
var PROP = PropertiesService.getScriptProperties();

function doGet() {
  return ContentService.createTextOutput('kloca-lens vision proxy ok')
    .setMimeType(ContentService.MimeType.TEXT);
}

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var image = data.image;
    var mime = data.mime || 'image/jpeg';
    if (!image) return json({ error: 'no image' });
    var key = PROP.getProperty('GEMINI_KEY');
    if (!key) return json({ error: 'no key' });
    var url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' + key;
    var payload = {
      contents: [{ parts: [
        { text: '이 사진 속 음식 또는 식품의 이름을 한국어로 하나만 답해. 다른 말 없이 이름만. 예: 아보카도' },
        { inline_data: { mime_type: mime, data: image } }
      ]}],
      generationConfig: { maxOutputTokens: 30 }
    };
    var r = UrlFetchApp.fetch(url, {
      method: 'post',
      contentType: 'application/json',
      payload: JSON.stringify(payload),
      muteHttpExceptions: true
    });
    var j = JSON.parse(r.getContentText());
    var c = j.candidates && j.candidates[0];
    var p = c && c.content && c.content.parts;
    var name = (p && p[0] && p[0].text || '').trim();
    return json({ name: name });
  } catch (err) {
    return json({ error: 'proxy failed' });
  }
}

function json(o) {
  return ContentService.createTextOutput(JSON.stringify(o))
    .setMimeType(ContentService.MimeType.JSON);
}
