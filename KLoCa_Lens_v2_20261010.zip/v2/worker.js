// Cloudflare Worker: kloca-lens-vision
// 사진(base64) -> Gemini vision -> 음식 이름(한국어) 반환
// GEMINI_KEY는 worker secret으로 등록 (코드에 키를 넣지 않는다)
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === 'GET') {
      return new Response('kloca-lens vision proxy ok');
    }
    if (request.method !== 'POST') {
      return new Response('method not allowed', { status: 405 });
    }
    try {
      const { image } = await request.json();
      if (!image) return Response.json({ error: 'no image' }, { status: 400 });
      const r = await fetch(
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' + env.GEMINI_KEY,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [
              { text: '이 사진 속 음식 또는 식품의 이름을 한국어로 하나만 답해. 다른 말 없이 이름만. 예: 아보카도' },
              { inline_data: { mime_type: 'image/jpeg', data: image } }
            ]}],
            generationConfig: { maxOutputTokens: 30 }
          })
        }
      );
      const j = await r.json();
      const p = j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts;
      const name = (p && p[0] && p[0].text || '').trim();
      return Response.json({ name });
    } catch (e) {
      return Response.json({ error: 'proxy failed' }, { status: 500 });
    }
  }
};
